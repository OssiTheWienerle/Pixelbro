function spawnBoss(scene) {
    gameState = 'BOSS';
    let bossX = LEVELS[currentLevelIndex]?.length - 200 || 1800;
    let bossY = 300;
    
    scene.boss = new Boss(scene, bossX, bossY, difficulty);
    scene.physics.add.collider(scene.boss, platforms);
    
    // Add overlap once
    scene.physics.add.overlap(scene.boss.bullets, player, (bullet, p) => {
        if (!p || !p.active || !bullet || !bullet.active) return;
        p.takeDamage(20);
        bullet.destroy();
    });

    scene.add.text(bossX, 100, 'FINAL BOSS', { fontSize: '64px', fill: '#f00' }).setOrigin(0.5);
}

class Boss extends Phaser.Physics.Arcade.Sprite {
    constructor(scene, x, y, difficulty) {
        super(scene, x, y, 'boss');
        scene.add.existing(this);
        scene.physics.add.existing(this);
        
        this.setCollideWorldBounds(true);
        this.difficulty = difficulty;

        const stats = {
            'Easy': { hp: 500, shootRate: 2000 },
            'Normal': { hp: 1000, shootRate: 1500 },
            'Hard': { hp: 2000, shootRate: 1000 },
            'Impossible': { hp: 3000, shootRate: 500 }
        };

        const currentStats = stats[difficulty] || stats['Easy'];
        this.hp = currentStats.hp;
        this.maxHp = this.hp;
        this.shootRate = stats[difficulty].shootRate;
        this.lastFired = 0;
        this.phase = 1;

        this.bullets = scene.physics.add.group({
            defaultKey: 'bullet'
        });

        // Health Bar
        this.healthBar = scene.add.graphics().setScrollFactor(0);
        this.updateHealthBar();
    }

    update() {
        if (!this || !this.active || !this.scene) return;

        // Boss Movement: Hover up and down, and move towards player slightly
        this.setVelocityY(Math.sin(this.scene.time.now / 500) * 100);
        
        if (this.x - player.x > 200) {
            this.setVelocityX(-50);
        } else if (this.x - player.x < 100) {
            this.setVelocityX(50);
        } else {
            this.setVelocityX(0);
        }

        // Shooting
        if (this.scene.time.now > this.lastFired) {
            this.shoot();
            this.lastFired = this.scene.time.now + this.shootRate;
        }

        this.updateHealthBar();
    }

    shoot() {
        // Multi-shot
        for (let i = -1; i <= 1; i++) {
            let bullet = this.bullets.get(this.x, this.y);
            if (!bullet) continue;
            
            bullet.setActive(true).setVisible(true);
            bullet.setTint(0xff00ff);
            bullet.setScale(2);
            bullet.body.allowGravity = false;
            
            let angle = Phaser.Math.Angle.Between(this.x, this.y, player.x, player.y) + (i * 0.2);
            this.scene.physics.velocityFromRotation(angle, 400, bullet.body.velocity);

            this.scene.time.delayedCall(4000, () => { if(bullet.active) bullet.destroy(); });
        }
    }

    updateHealthBar() {
        this.healthBar.clear();
        this.healthBar.fillStyle(0x000000);
        this.healthBar.fillRect(100, 20, 200, 10);
        this.healthBar.fillStyle(0xff0000);
        this.healthBar.fillRect(100, 20, 200 * (this.hp / this.maxHp), 10);
    }

    takeDamage(amount) {
        if (!this || !this.active) return;
        this.hp -= amount;
        this.setTint(0xffffff);
        
        if (this.scene && this.scene.time) {
            this.scene.time.delayedCall(100, () => { if(this.active) this.clearTint(); });
        }
        
        if (this.hp <= 0) {
            this.die();
        }
    }

    die() {
        gameState = 'WIN';
        this.scene.add.text(player.x, player.y - 100, 'MISSION ACCOMPLISHED', { fontSize: '24px', fill: '#0f0' }).setOrigin(0.5);
        this.healthBar.clear();
        this.destroy();
        
        currentLevelIndex++;
        if (currentLevelIndex >= LEVELS.length) {
            this.scene.add.text(player.x, player.y - 50, 'GAME CLEAR!', { fontSize: '32px', fill: '#ff0' }).setOrigin(0.5);
            this.scene.time.delayedCall(5000, () => location.reload());
        } else {
            this.scene.time.delayedCall(3000, () => initLevel(this.scene));
        }
    }
}
