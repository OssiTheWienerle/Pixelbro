const DIFFICULTY_SETTINGS = {
    'Easy': { 
        playerHp: 200, 
        specialCharges: 5, 
        enemyHp: 50, 
        enemyCount: 20,
        shootRate: 4000,
        doubleShotChance: 0
    },
    'Normal': { 
        playerHp: 150, 
        specialCharges: 3, 
        enemyHp: 100, 
        enemyCount: 30,
        shootRate: 3000,
        doubleShotChance: 0
    },
    'Hard': { 
        playerHp: 100, 
        specialCharges: 2, 
        enemyHp: 150, 
        enemyCount: 40,
        shootRate: 2000,
        doubleShotChance: 0.1
    },
    'Impossible': { 
        playerHp: 100, 
        specialCharges: 1, 
        enemyHp: 200, 
        enemyCount: 50,
        shootRate: 1000,
        doubleShotChance: 0.3
    }
};

const LEVELS = [
    {
        name: "Level 1: The Outskirts",
        length: 2000,
        structures: [
            { x: 400, type: 'bunker' },
            { x: 800, type: 'special_bunker' },
            { x: 1200, type: 'bunker' }
        ]
    },
    {
        name: "Level 2: The Fortress",
        length: 3000,
        structures: [
            { x: 500, type: 'bunker' },
            { x: 1000, type: 'bunker' },
            { x: 1500, type: 'bunker' },
            { x: 2000, type: 'bunker' }
        ]
    }
];
