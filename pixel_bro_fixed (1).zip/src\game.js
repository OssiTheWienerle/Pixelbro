const config = {
    type: Phaser.AUTO,
    width: 400,
    height: 225,
    parent: 'game-container',
    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH
    },
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 800 },
            debug: false
        }
    },
    scene: {
        preload: preload,
        create: create,
        update: update
    },
    pixelArt: true
};

let game = new Phaser.Game(config);
let player;
let cursors;
let enemies;
let platforms;
let difficulty = 'Easy';
let currentLevelIndex = 0;
let gameState = 'START'; // START, PLAYING, BOSS, GAMEOVER, WIN
let soundEnabled = true;

let keybinds = {
    UP: Phaser.Input.Keyboard.KeyCodes.W,
    DOWN: Phaser.Input.Keyboard.KeyCodes.S,
    LEFT: Phaser.Input.Keyboard.KeyCodes.A,
    RIGHT: Phaser.Input.Keyboard.KeyCodes.D,
    ATTACK: Phaser.Input.Keyboard.KeyCodes.J,
    SPECIAL: Phaser.Input.Keyboard.KeyCodes.K,
    MELEE: Phaser.Input.Keyboard.KeyCodes.L,
    HEAL: Phaser.Input.Keyboard.KeyCodes.H
};

const DEFAULT_KEYBINDS = { ...keybinds };

function preload() {
}

function create() {
    this.cameras.main.setBackgroundColor('#87CEEB');
    createTextures(this);
    this.particles = this.add.particles(0, 0, 'bullet', {
        speed: { min: -100, max: 100 },
        scale: { start: 1, end: 0 },
        lifespan: 500,
        emitting: false
    }).setDepth(10);

    // Procedural Audio placeholders (Simplified Synthesis)
    try {
        this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
    } catch (e) {
        console.warn("AudioContext not supported", e);
    }

    const playNote = (freq, duration, type = 'square') => {
        if (!soundEnabled || !this.audioContext) return;
        const ctx = this.audioContext;
        try {
            if (ctx.state === 'suspended') ctx.resume();
        } catch (e) { return; }
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, ctx.currentTime);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + duration);
    };

    this.sounds = {
        shoot: { play: () => playNote(440, 0.1) },
        special: { play: () => { playNote(110, 0.5); playNote(220, 0.5); } },
        enemy: { play: () => playNote(200, 0.2, 'sawtooth') },
        boss: { play: () => playNote(100, 0.8, 'sawtooth') },
        music: { play: () => { }, stop: () => { } }
    };

    showStartScreen(this);
}

function update() {
    if (gameState === 'PLAYING' || gameState === 'BOSS') {
        if (player) player.update();
        if (enemies) {
            enemies.getChildren().forEach(enemy => {
                if (enemy.update) enemy.update();
            });
        }
        if (this.boss && this.boss.update) {
            this.boss.update();
        }
    }
}

function createTextures(scene) {
    let graphics = scene.make.graphics({ x: 0, y: 0, add: false });

    // Player (24x24)
    graphics.fillStyle(0x1a1a1a); graphics.fillRect(6, 14, 12, 10);
    graphics.fillStyle(0x000088); graphics.fillRect(6, 8, 12, 8);
    graphics.fillStyle(0xffdbac); graphics.fillRect(7, 0, 10, 9);
    graphics.fillStyle(0x442200); graphics.fillRect(7, 5, 10, 5);
    graphics.fillStyle(0xff0000); graphics.fillRect(6, 2, 12, 3);
    graphics.fillRect(0, 2, 6, 1);
    graphics.fillStyle(0x000000); graphics.fillRect(9, 3, 2, 2); graphics.fillRect(13, 3, 2, 2);
    graphics.fillStyle(0x555555); graphics.fillRect(16, 10, 8, 4);
    graphics.fillStyle(0x333333); graphics.fillRect(18, 12, 4, 2);
    graphics.generateTexture('player', 24, 24);
    graphics.clear();

    // Enemy (24x24)
    graphics.fillStyle(0x2d3a2d); graphics.fillRect(6, 12, 12, 12);
    graphics.fillStyle(0x3e4d3e); graphics.fillRect(6, 8, 12, 6);
    graphics.fillStyle(0x000000); graphics.fillRect(7, 9, 10, 4);
    graphics.fillStyle(0x1a1a1a); graphics.fillRect(6, 0, 12, 8);
    graphics.fillStyle(0x333333); graphics.fillRect(6, 1, 12, 2);
    graphics.fillStyle(0xffdbac); graphics.fillRect(7, 6, 10, 3);
    graphics.fillStyle(0xff0000); graphics.fillRect(8, 7, 2, 2); graphics.fillRect(12, 7, 2, 2);
    graphics.fillStyle(0x000000); graphics.fillRect(16, 12, 8, 4);
    graphics.fillStyle(0x555555); graphics.fillRect(20, 12, 4, 1);
    graphics.generateTexture('enemy', 24, 24);
    graphics.clear();

    // Bullets
    graphics.fillStyle(0xffff00); graphics.fillRect(0, 0, 4, 2);
    graphics.generateTexture('bullet', 4, 2);
    graphics.clear();

    graphics.fillStyle(0xffaa00); graphics.fillRect(2, 0, 6, 4);
    graphics.fillStyle(0x884400); graphics.fillRect(0, 0, 2, 4);
    graphics.generateTexture('enemy_bullet', 8, 4);
    graphics.clear();

    // Mega Bullet (3 blocks tall = 72px)
    graphics.fillStyle(0xff0000); graphics.fillRect(0, 0, 32, 72);
    graphics.fillStyle(0xffffff); graphics.fillRect(4, 4, 24, 64);
    graphics.fillStyle(0xffff00); graphics.fillRect(8, 8, 16, 56);
    graphics.generateTexture('mega_bullet', 32, 72);
    graphics.clear();

    // Blocks
    graphics.fillStyle(0x663300); graphics.fillRect(0, 0, 24, 24);
    graphics.fillStyle(0x228B22); graphics.fillRect(0, 0, 24, 6);
    graphics.fillStyle(0x000000, 0.2); graphics.fillRect(0, 20, 24, 4);
    graphics.generateTexture('block', 24, 24);
    graphics.clear();

    // Bedrock (undestroyable)
    graphics.fillStyle(0x222222); graphics.fillRect(0, 0, 24, 24);
    graphics.fillStyle(0x000000); graphics.fillRect(0, 0, 24, 2); graphics.fillRect(0, 0, 2, 24);
    graphics.fillStyle(0x444444); graphics.fillRect(22, 0, 2, 24); graphics.fillRect(0, 22, 2, 24);
    graphics.generateTexture('bedrock', 24, 24);
    graphics.clear();

    graphics.fillStyle(0x444444); graphics.fillRect(0, 0, 24, 24);
    graphics.fillStyle(0x666666); graphics.fillRect(2, 2, 20, 20);
    graphics.fillStyle(0x222222); graphics.fillRect(4, 4, 16, 16);
    graphics.generateTexture('stone', 24, 24);
    graphics.clear();

    // Items
    graphics.fillStyle(0xffffff); graphics.fillRect(0, 0, 24, 24);
    graphics.fillStyle(0xff0000); graphics.fillRect(10, 4, 4, 16); graphics.fillRect(4, 10, 16, 4);
    graphics.generateTexture('medikit', 24, 24);
    graphics.clear();

    graphics.fillStyle(0x0000ff); graphics.fillRect(0, 0, 24, 24);
    graphics.fillStyle(0xffffff); graphics.fillRect(4, 4, 16, 4);
    graphics.fillStyle(0x0000cc); graphics.fillRect(4, 10, 16, 10);
    graphics.generateTexture('special_crate', 24, 24);
    graphics.clear();

    // Boss
    graphics.fillStyle(0x333333); graphics.fillRect(0, 12, 48, 36);
    graphics.fillStyle(0x555555); graphics.fillRect(8, 4, 32, 12);
    graphics.fillStyle(0xff0000); graphics.fillRect(12, 8, 4, 4); graphics.fillRect(32, 8, 4, 4);
    graphics.generateTexture('boss', 48, 48);
    graphics.clear();
}

function showStartScreen(scene) {
    scene.children.removeAll();
    scene.add.text(200, 40, 'PIXEL BRO', { fontSize: '28px', fill: '#fff', stroke: '#000', strokeThickness: 4 }).setOrigin(0.5);
    let items = [
        { name: 'Start', y: 80, action: () => { currentLevelIndex = 0; initLevel(scene); } },
        {
            name: 'Continue', y: 105, action: () => {
                let saved = localStorage.getItem('pixelBroLevel');
                if (saved) currentLevelIndex = parseInt(saved);
                initLevel(scene);
            }
        },
        { name: 'Options', y: 130, action: () => showOptions(scene) }
    ];
    items.forEach(item => {
        let btn = scene.add.text(200, item.y, item.name, { fontSize: '14px', fill: '#fff' }).setOrigin(0.5).setInteractive();
        btn.on('pointerdown', item.action);
    });
}

function showOptions(scene) {
    scene.children.removeAll();
    scene.add.text(200, 30, 'OPTIONS', { fontSize: '20px', fill: '#fff' }).setOrigin(0.5);
    let soundBtn = scene.add.text(200, 60, `Sound: ${soundEnabled ? 'ON' : 'OFF'}`, { fontSize: '14px', fill: '#fff' }).setOrigin(0.5).setInteractive();
    soundBtn.on('pointerdown', () => {
        soundEnabled = !soundEnabled;
        soundBtn.setText(`Sound: ${soundEnabled ? 'ON' : 'OFF'}`);
    });
    scene.add.text(200, 90, `Difficulty: ${difficulty}`, { fontSize: '14px', fill: '#fff' }).setOrigin(0.5).setInteractive().on('pointerdown', () => showDifficultySelect(scene));
    scene.add.text(200, 120, 'Keybinds', { fontSize: '14px', fill: '#fff' }).setOrigin(0.5).setInteractive().on('pointerdown', () => showKeybinds(scene));
    scene.add.text(200, 150, 'Back', { fontSize: '14px', fill: '#ff0' }).setOrigin(0.5).setInteractive().on('pointerdown', () => showStartScreen(scene));
}

function showDifficultySelect(scene) {
    scene.children.removeAll();
    scene.add.text(200, 40, 'SELECT DIFFICULTY', { fontSize: '20px', fill: '#fff' }).setOrigin(0.5);
    ['Easy', 'Normal', 'Hard', 'Impossible'].forEach((mode, i) => {
        scene.add.text(200, 75 + i * 25, mode, { fontSize: '14px', fill: (difficulty === mode ? '#f00' : '#fff') }).setOrigin(0.5).setInteractive().on('pointerdown', () => { difficulty = mode; showOptions(scene); });
    });
}

function showKeybinds(scene) {
    scene.children.removeAll();
    scene.add.text(200, 25, 'KEYBINDS', { fontSize: '18px', fill: '#fff' }).setOrigin(0.5);

    let y = 55;
    Object.keys(keybinds).forEach(action => {
        let keyName = Phaser.Input.Keyboard.KeyCodes[keybinds[action]];
        // Find human readable name
        for (let k in Phaser.Input.Keyboard.KeyCodes) {
            if (Phaser.Input.Keyboard.KeyCodes[k] === keybinds[action]) {
                keyName = k; break;
            }
        }
        let btn = scene.add.text(200, y, `${action}: ${keyName}`, { fontSize: '12px', fill: '#fff' }).setOrigin(0.5).setInteractive();
        btn.on('pointerdown', () => {
            btn.setText(`Press any key for ${action}...`);
            scene.input.keyboard.once('keydown', (event) => {
                keybinds[action] = event.keyCode;
                showKeybinds(scene);
            });
        });
        y += 18;
    });

    scene.add.text(200, y + 10, 'Reset', { fontSize: '14px', fill: '#f0f' }).setOrigin(0.5).setInteractive().on('pointerdown', () => {
        keybinds = { ...DEFAULT_KEYBINDS };
        showKeybinds(scene);
    });

    scene.add.text(200, y + 35, 'Back', { fontSize: '14px', fill: '#ff0' }).setOrigin(0.5).setInteractive().on('pointerdown', () => showOptions(scene));
}

function initLevel(scene) {
    // CRITICAL: Fully clear existing physics and objects
    if (player) { player.destroy(); player = null; }
    if (enemies) { enemies.clear(true, true); }
    if (platforms) { platforms.clear(true, true); }
    if (scene.medikits) { scene.medikits.clear(true, true); }
    if (scene.specialCrates) { scene.specialCrates.clear(true, true); }
    if (scene.enemyBullets) { scene.enemyBullets.clear(true, true); }
    if (scene.explosions) { scene.explosions.clear(true, true); }
    if (scene.boss) { scene.boss.destroy(); scene.boss = null; }

    // Clear all existing colliders/overlaps to prevent reference errors
    scene.physics.world.colliders.destroy();

    gameState = 'PLAYING';
    const levelData = LEVELS[currentLevelIndex] || LEVELS[0];
    const settings = DIFFICULTY_SETTINGS[difficulty] || DIFFICULTY_SETTINGS['Easy'];
    localStorage.setItem('pixelBroLevel', currentLevelIndex);

    platforms = scene.physics.add.staticGroup();
    scene.medikits = scene.physics.add.staticGroup();
    scene.specialCrates = scene.physics.add.staticGroup();
    scene.medikits.setDepth(5);
    scene.specialCrates.setDepth(5);
    scene.explosions = scene.physics.add.group();

    // STRICT 24px GRID HELPER
    const getY = (row) => 213 - row * 24;

    // GROUND
    for (let i = 0; i < levelData.length / 24; i++) {
        platforms.create(i * 24 + 12, getY(0), 'block');
        platforms.create(i * 24 + 12, getY(-1), 'bedrock');
    }

    // Structures
    levelData.structures.forEach(s => {
        let gx = Math.floor(s.x / 24) * 24;
        if (s.type === 'bunker') spawnStoneMedikitStructure(scene, gx, getY(2) - 12);
        else if (s.type === 'special_bunker') spawnStoneSpecialStructure(scene, gx, getY(2) - 12);
    });

    // Random platforms aligned to grid
    for (let i = 0; i < 15; i++) {
        let gx = Phaser.Math.Between(10, (levelData.length / 24) - 10) * 24;
        let gy = getY(Phaser.Math.Between(2, 4));
        platforms.create(gx + 12, gy, 'block');
        platforms.create(gx + 36, gy, 'block');
    }

    player = new Player(scene, 48, 140, difficulty);
    enemies = scene.physics.add.group();
    for (let i = 0; i < settings.enemyCount; i++) {
        enemies.add(new Enemy(scene, Phaser.Math.Between(600, levelData.length - 400), 100, difficulty));
    }

    scene.physics.add.collider(player, platforms);
    scene.physics.add.collider(enemies, platforms);
    if (difficulty === 'Impossible') scene.physics.world.setFPS(120);

    scene.physics.add.collider(player.bullets, platforms, (b, block) => { b.destroy(); handleBlockHit(scene, block); });
    scene.physics.add.overlap(player.bullets, enemies, (b, e) => { e.takeDamage(25); b.destroy(); });

    scene.enemyBullets = scene.physics.add.group();
    scene.physics.add.overlap(scene.enemyBullets, player, (arg1, arg2) => {
        let p = (arg1 instanceof Player) ? arg1 : arg2;
        let bullet = (p === arg1) ? arg2 : arg1;

        if (!p || !p.active || !bullet || !bullet.active) return;
        if (typeof p.takeDamage === 'function') {
            p.takeDamage(20);
        }
        bullet.destroy();
    });
    scene.physics.add.collider(scene.enemyBullets, platforms, (b, block) => { b.destroy(); handleBlockHit(scene, block); });

    scene.physics.add.overlap(scene.explosions, enemies, (exp, enemy) => enemy.takeDamage(100));
    scene.physics.add.overlap(scene.explosions, platforms, (exp, block) => handleBlockHit(scene, block, 3));

    scene.cameras.main.startFollow(player, true, 0.2, 0.2);
    scene.cameras.main.setBounds(0, 0, levelData.length, 225);
    scene.physics.world.setBounds(0, 0, levelData.length, 225);
    scene.bossTriggered = false;
}

function spawnStoneMedikitStructure(scene, x, y) {
    for (let r = 0; r < 3; r++) {
        for (let c = 0; c < 3; c++) {
            let px = x + c * 24 + 12; let py = y - r * 24 + 12;
            if (r === 1 && c === 1) scene.medikits.create(px, py, 'medikit');
            else { let s = platforms.create(px, py, 'stone'); s.hp = 3; }
        }
    }
}

function spawnStoneSpecialStructure(scene, x, y) {
    for (let r = 0; r < 3; r++) {
        for (let c = 0; c < 3; c++) {
            let px = x + c * 24 + 12; let py = y - r * 24 + 12;
            if (r === 1 && c === 1) scene.specialCrates.create(px, py, 'special_crate');
            else { let s = platforms.create(px, py, 'stone'); s.hp = 3; }
        }
    }
}

function handleBlockHit(scene, block, damage = 1) {
    if (block.texture.key === 'bedrock') return;
    if (block.texture.key === 'stone') {
        if (block.hp === undefined) block.hp = 3;
        block.hp -= damage;
        if (block.hp <= 0) block.destroy();
        else { block.setTint(0x888888); scene.time.delayedCall(100, () => { if (block.active) block.clearTint(); }); }
    } else block.destroy();
}
