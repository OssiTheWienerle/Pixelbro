class Enemy extends Phaser.Physics.Arcade.Sprite {
    constructor(scene, x, y, difficulty) {
        super(scene, x, y, 'enemy');
        scene.add.existing(this);
        scene.physics.add.existing(this);

        this.setCollideWorldBounds(true);
        this.difficulty = difficulty;

        const stats = {
            'Easy': { hp: 90, shootRate: 3000, speed: 50 },
            'Normal': { hp: 90, shootRate: 2000, speed: 100 },
            'Hard': { hp: 90, shootRate: 1500, speed: 150 },
            'Impossible': { hp: 90, shootRate: 1000, speed: 200 }
        };

        const currentStats = stats[difficulty] || stats['Easy'];
        this.hp = currentStats.hp;
        this.shootRate = currentStats.shootRate;
        this.speed = currentStats.speed;
        this.lastFired = 0;
        this.loSCheckTimer = Phaser.Math.Between(0, 10); // Offset for staggered LoS checks

        // Idle turning timer (recursive for dynamic random delay)
        this.setupIdleTurn();
    }

    setupIdleTurn() {
        if (!this || !this.active || !this.scene) return;
        this.scene.time.delayedCall(Phaser.Math.Between(3000, 5000), () => {
            if (this.active && this.scene && !this.canSeePlayer()) {
                this.setFlipX(!this.flipX);
            }
            this.setupIdleTurn();
        });
    }

    update() {
        if (!this || !this.active || !this.scene || !player || !player.active) return;

        this.loSCheckTimer++;

        let dist = Phaser.Math.Distance.Between(this.x, this.y, player.x, player.y);

        if (dist < 300) {
            // Only check LoS once every 10 frames to save CPU
            if (this.loSCheckTimer % 10 === 0) {
                this.lastCanSee = this.canSeePlayer();
            }

            if (this.lastCanSee) {
                // Eye contact logic: Turn towards player if they are within sight
                // But only if they were already facing that way or if player is very close
                if (this.x < player.x) {
                    this.setFlipX(false);
                } else {
                    this.setFlipX(true);
                }

                if (this.scene.time.now > this.lastFired) {
                    this.shoot();

                    const settings = DIFFICULTY_SETTINGS[this.difficulty] || DIFFICULTY_SETTINGS['Easy'];
                    let delay = settings.shootRate || 3000;

                    // Impossible double-shot logic
                    if (Math.random() < (settings.doubleShotChance || 0)) {
                        this.scene.time.delayedCall(200, () => {
                            if (this.active && this.canSeePlayer()) this.shoot();
                        });
                    }

                    this.lastFired = this.scene.time.now + delay + Phaser.Math.Between(0, 500);
                }
            }
        }

        this.setVelocityX(0); // Stay at their point
        this.angle = 0;
    }

    canSeePlayer() {
        if (!this || !this.active || !this.scene || !player || !player.active) return false;

        let dist = Phaser.Math.Distance.Between(this.x, this.y, player.x, player.y);
        if (dist > 300) return false; // Too far to see

        // Facing check (Eye Contact)
        const isFacingPlayer = (this.flipX && player.x < this.x) || (!this.flipX && player.x > this.x);
        // If not facing player, only "see" them if they are extremely close (noise/stealth)
        if (!isFacingPlayer && dist > 50) return false;

        let line = new Phaser.Geom.Line(this.x, this.y, player.x, player.y);
        let blocks = platforms.getChildren();

        // Only check blocks that are roughly between enemy and player to save performance
        // Use a simple bounding box check
        let minX = Math.min(this.x, player.x);
        let maxX = Math.max(this.x, player.x);
        let minY = Math.min(this.y, player.y);
        let maxY = Math.max(this.y, player.y);

        for (let block of blocks) {
            let bx = block.x;
            let by = block.y;
            // Rough proximity check for block
            if (bx >= minX - 24 && bx <= maxX + 24 && by >= minY - 24 && by <= maxY + 24) {
                if (Phaser.Geom.Intersects.LineToRectangle(line, block.getBounds())) {
                    return false;
                }
            }
        }
        return true;
    }

    shoot() {
        if (!this.scene.enemyBullets) return;

        if (soundEnabled && this.scene.sounds) this.scene.sounds.enemy.play();

        let bullet = this.scene.enemyBullets.create(this.x, this.y, 'enemy_bullet');
        bullet.body.allowGravity = false;

        let angle = Phaser.Math.Angle.Between(this.x, this.y, player.x, player.y);
        this.scene.physics.velocityFromRotation(angle, 150, bullet.body.velocity);
        bullet.setRotation(angle);

        // Range 2/3 of 400px = 266px. 266/150 = 1.77s
        this.scene.time.delayedCall(1770, () => { if (bullet.active) bullet.destroy(); });
    }

    takeDamage(amount) {
        if (!this || !this.active) return;
        this.hp -= amount;

        // Alerted: turn towards player
        if (player && player.active) {
            this.setFlipX(player.x < this.x);
        }

        this.setTint(0xffffff);

        if (this.scene && this.scene.time) {
            this.scene.time.delayedCall(100, () => { if (this.active) this.clearTint(); });
        }

        // Particles
        if (this.scene && this.scene.particles && typeof this.scene.particles.explode === 'function') {
            this.scene.particles.explode(5, this.x, this.y);
        }

        if (this.hp <= 0) {
            if (this.scene && this.scene.cameras && this.scene.cameras.main) {
                this.scene.cameras.main.shake(200, 0.02);
            }
            this.destroy();
        }
    }
}
