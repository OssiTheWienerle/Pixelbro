const DIFFICULTY_SETTINGS = {
    'Easy': {
        playerHp: 500,
        specialCharges: 5,
        enemyHp: 30,
        enemyCount: 5,
        shootRate: 8000,
        doubleShotChance: 0
    },
    'Normal': {
        playerHp: 200,
        specialCharges: 3,
        enemyHp: 60,
        enemyCount: 10,
        shootRate: 6000,
        doubleShotChance: 0.05
    },
    'Hard': {
        playerHp: 150,
        specialCharges: 2,
        enemyHp: 100,
        enemyCount: 14,
        shootRate: 4000,
        doubleShotChance: 0.15
    },
    'Impossible': {
        playerHp: 100,
        specialCharges: 1,
        enemyHp: 150,
        enemyCount: 20,
        shootRate: 2500,
        doubleShotChance: 0.4
    }
};

const LEVELS = [
    {
        name: "Level 1: Tutorial Hills",
        length: 12000,
        blocks: [], // Hand-crafted block data
        structures: [],
        enemies: [],
        barrels: [],
        ladders: []
    },
    {
        name: "Level 2: Verticality",
        length: 12000,
        bossStats: {
            'Easy': { hp: 1000, shootRate: 4000 },
            'Normal': { hp: 1200, shootRate: 3000 },
            'Hard': { hp: 1500, shootRate: 2000 },
            'Impossible': { hp: 2000, shootRate: 1000 }
        },
        blocks: [],
        structures: [],
        enemies: [],
        barrels: [],
        ladders: []
    },
    {
        name: "Level 3: Complex Terrain",
        length: 12000,
        bossStats: {
            'Easy': { hp: 1500, shootRate: 3500 },
            'Normal': { hp: 1800, shootRate: 2500 },
            'Hard': { hp: 2200, shootRate: 1500 },
            'Impossible': { hp: 3000, shootRate: 800 }
        },
        blocks: [],
        structures: [],
        enemies: [],
        barrels: [],
        ladders: []
    }
];

// Helper to generate level 1 data
function generateLevel1() {
    const level = LEVELS[0];
    // Underground base (150px = 6.25 blocks, let's say 6 blocks of dirt, 1 block of bedrock)
    for (let x = 0; x < 12000; x += 24) {
        level.blocks.push({ x: x + 12, y: 450 - 12, type: 'bedrock' });
        for (let y = 1; y < 7; y++) {
            level.blocks.push({ x: x + 12, y: 450 - y * 24 - 12, type: 'block' });
        }
    }
    // Moderate Hills
    for (let x = 400; x < 11000; x += 800) {
        let h = Math.floor(Math.random() * 3) + 1;
        for (let dx = 0; dx < 200; dx += 24) {
            for (let dy = 0; dy < h; dy++) {
                level.blocks.push({ x: x + dx + 12, y: 450 - (7 + dy) * 24 - 12, type: 'block' });
            }
        }
    }
    // Floating Islands
    for (let x = 1000; x < 11000; x += 1500) {
        for (let dx = 0; dx < 120; dx += 24) {
             level.blocks.push({ x: x + dx, y: 200, type: 'block' });
        }
    }
    // Barrels (Single spawns)
    for (let x = 800; x < 11000; x += 1000) {
        level.barrels.push({ x: x, y: 250 });
    }
    // Ladders
    for (let x = 1000; x < 11000; x += 2000) {
        for (let y = 200; y < 282; y += 24) {
             level.ladders.push({ x: x - 12, y: y });
        }
    }
    // Enemies
    for (let x = 1500; x < 11000; x += 1200) {
        level.enemies.push({ x: x, y: 250 });
    }
}

// Level 2 Verticality
function generateLevel2() {
    const level = LEVELS[1];
    for (let x = 0; x < 12000; x += 24) {
        level.blocks.push({ x: x + 12, y: 450 - 12, type: 'bedrock' });
        for (let y = 1; y < 7; y++) {
            level.blocks.push({ x: x + 12, y: 450 - y * 24 - 12, type: 'block' });
        }
    }
    // Multi-layer platforms
    for (let x = 500; x < 11000; x += 600) {
        let layers = [120, 220, 320];
        layers.forEach(ly => {
            for (let dx = 0; dx < 150; dx += 24) {
                level.blocks.push({ x: x + dx, y: ly, type: 'block' });
            }
        });
        // Ladders to connect layers
        for (let ly = 120; ly < 400; ly += 24) {
            level.ladders.push({ x: x + 75, y: ly });
        }
    }
    // Enemies on different layers
    for (let x = 1000; x < 11000; x += 1000) {
        level.enemies.push({ x: x, y: 100 });
        level.enemies.push({ x: x + 300, y: 200 });
    }
    // Barrels
    for (let x = 1200; x < 11000; x += 1500) {
        level.barrels.push({ x: x, y: 200 });
    }
}

// Level 3 Complex Terrain
function generateLevel3() {
    const level = LEVELS[2];
    for (let x = 0; x < 12000; x += 24) {
        level.blocks.push({ x: x + 12, y: 450 - 12, type: 'bedrock' });
        for (let y = 1; y < 7; y++) {
            level.blocks.push({ x: x + 12, y: 450 - y * 24 - 12, type: 'block' });
        }
    }
    // Tunnels (1-block high)
    for (let x = 2000; x < 10000; x += 3000) {
        // Create a thick block and carve a tunnel
        for (let tx = 0; tx < 500; tx += 24) {
            for (let ty = 0; ty < 5; ty++) {
                if (ty !== 2) { // Gap at row 2
                    level.blocks.push({ x: x + tx, y: 250 + ty * 24, type: 'stone' });
                }
            }
        }
    }
    // Floating islands and complex jumps
    for (let x = 1000; x < 11000; x += 800) {
        level.blocks.push({ x: x, y: 150, type: 'block' });
        level.blocks.push({ x: x + 100, y: 300, type: 'block' });
        level.enemies.push({ x: x + 50, y: 100 });
    }
    // Barrels
    for (let x = 1500; x < 11000; x += 2000) {
        level.barrels.push({ x: x, y: 100 });
    }
}

generateLevel1();
generateLevel2();
generateLevel3();
